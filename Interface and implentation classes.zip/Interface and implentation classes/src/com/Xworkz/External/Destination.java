package com.Xworkz.External;

import com.Xworkz.Internal.car;

public class Destination implements car {
    @Override
    public void drivingRulls() {
        System.out.println("Driving Rulls");
    }

    @Override
    public void speedRulls() {
        System.out.println("Speed Rulls");
    }

    @Override
    public void rulls() {
        System.out.println("Driving Rulls");

    }
}
