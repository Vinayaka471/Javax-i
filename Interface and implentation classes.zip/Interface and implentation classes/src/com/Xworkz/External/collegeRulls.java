package com.Xworkz.External;

import com.Xworkz.Internal.college;

public class collegeRulls implements college {
    @Override
    public void feesRulls() {
        System.out.println("Fees Rulls");
    }

    @Override
    public void streemRulls() {
        System.out.println("Streem Rulls");
    }

    @Override
    public void courseRulls() {
        System.out.println("Course Rulls");
    }
}