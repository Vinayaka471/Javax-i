package com.Xworkz.External;

import com.Xworkz.Internal.Appi;

public class AppiRulls implements Appi {
    @Override
    public void teacherRulls() {
        System.out.println("Teacher Rulls");
    }

    @Override
    public void principalRulls() {
        System.out.println("Principal Rulls");

    }

    @Override
    public void presidentRulls() {
        System.out.println("President Rulls");

    }
}
