package com.Xworkz.External;

import com.Xworkz.Internal.PG;

public class PgRulls implements PG {
    @Override
    public void fees() {
        System.out.println("PG Fees Rulls");
    }

    @Override
    public void food() {
        System.out.println("PG Food Rulls");

    }

    @Override
    public void admission() {
        System.out.println("Pg Admission Rulls");

    }
}
