package com.Xworkz.External;

import com.Xworkz.Internal.Arav;

public class AravRull implements Arav {
    @Override
    public void teacherRulls() {
        System.out.println("Teacher Rulls");
    }

    @Override
    public void principalRulls() {
        System.out.println("Principal Rulls");

    }

    @Override
    public void presidentRulls() {
        System.out.println("President Rulls");

    }
}
