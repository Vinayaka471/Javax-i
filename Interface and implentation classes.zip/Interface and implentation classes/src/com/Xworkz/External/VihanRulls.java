package com.Xworkz.External;

import com.Xworkz.Internal.Vihan;

public class VihanRulls implements Vihan {
    @Override
    public void teacherRulls() {
        System.out.println("Teacher Rulls");
    }

    @Override
    public void principalRulls() {
        System.out.println("Principal Rulls");

    }

    @Override
    public void presidentRulls() {
        System.out.println("President rulls");

    }
}
