package com.Xworkz.External;

import com.Xworkz.Internal.Bhrath;

public class BharathRulls implements Bhrath {
    @Override
    public void schoolRulls() {
        System.out.println("Bharath school Rulls");
    }

    @Override
    public void gameRulls() {
        System.out.println("Bharath Game Rulls");

    }

    @Override
    public void examRulls() {
        System.out.println("Bharath Exam Rulls");

    }
}
