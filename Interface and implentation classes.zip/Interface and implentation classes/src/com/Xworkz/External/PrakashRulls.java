package com.Xworkz.External;

import com.Xworkz.Internal.Prakash;

public class PrakashRulls implements Prakash {
    @Override
    public void schoolRulls() {
        System.out.println("School RUlls");
    }

    @Override
    public void gameRulls() {
        System.out.println("Game Rulls");

    }

    @Override
    public void examRulls() {
        System.out.println("Exam Rulls");

    }
}
