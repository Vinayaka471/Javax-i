package com.Xworkz.External;

import com.Xworkz.Internal.Aakhil;

public class aakhilRulls implements Aakhil {
    @Override
    public void collegeRulls() {
        System.out.println("College Rulls");

    }

    @Override
    public void schoolRulls() {
        System.out.println("School Rulls");

    }

    @Override
    public void homeRulls() {
        System.out.println("Home Rulls");

    }
}
