package com.Xworkz.External;

import com.Xworkz.Internal.Arun;

public class ArunRulls implements Arun {
    @Override
    public void schoolRulls() {
        System.out.println("Arun School Rulls");
    }

    @Override
    public void gameRulls() {
        System.out.println("Arun Game Rulls");
    }

    @Override
    public void examRulls() {
        System.out.println("Arun Exam Rulls");
    }
}
