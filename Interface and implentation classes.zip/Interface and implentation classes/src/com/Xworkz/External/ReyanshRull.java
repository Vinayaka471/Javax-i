package com.Xworkz.External;

import com.Xworkz.Internal.Reyansh;

public class ReyanshRull implements Reyansh {
    @Override
    public void schoolRulls() {
        System.out.println("School Rule");
    }

    @Override
    public void gameRulls() {
        System.out.println("Game Rules");

    }

    @Override
    public void examRulls() {
        System.out.println("Exam Rule");
    }
}
