package com.Xworkz.External;

import com.Xworkz.Internal.HomeStay;

public class HomeStayRulls implements HomeStay {
    @Override
    public void iteamRulls() {
        System.out.println("Home Stay Iteam Rulls");
    }

    @Override
    public void billRulls() {
        System.out.println("Home Stay Bills Rulls");

    }

    @Override
    public void orderRulls() {
        System.out.println("Home Stay Order List Rulls");

    }
}
