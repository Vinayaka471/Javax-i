package com.Xworkz.BrandClass;

import com.Xworkz.Internal.*;

public class Student29 implements  School, Shaurya, Tanmay , Hotel, Sell {
    @Override
    public void timeRulls() {
        System.out.println("Time Rules");

    }

    @Override
    public void schoolRulls() {
        System.out.println("School Rules");

    }

    @Override
    public void gameRulls() {
        System.out.println("Game Rules");

    }

    @Override
    public void examRulls() {
        System.out.println("Exam Rules");

    }

    @Override
    public void subRulls() {
        System.out.println("Sub Rules");

    }

    @Override
    public void iteamRulls() {
        System.out.println("Item Rules");

    }

    @Override
    public void billRulls() {
        System.out.println("Bill Rules");

    }

    @Override
    public void orderRulls() {
        System.out.println("Order Rules");

    }

    @Override
    public void documentRull() {
        System.out.println("Document Rules");

    }

    @Override
    public void priceRull() {
        System.out.println("Price Rules");

    }

    @Override
    public void changeRull() {
        System.out.println("Change Rules");

    }
}
