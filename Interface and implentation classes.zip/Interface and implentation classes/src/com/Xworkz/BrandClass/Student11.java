package com.Xworkz.BrandClass;

import com.Xworkz.Internal.Tanmay;
import com.Xworkz.Internal.Tarun;

public class Student11 implements Tanmay, Tarun {
    @Override
    public void schoolRulls() {
        System.out.println("School Rulls for Student.");
    }

    @Override
    public void gameRulls() {
        System.out.println("Game Rulls For Student.");

    }

    @Override
    public void examRulls() {
        System.out.println("Exam Rulls for Student.");

    }
}
