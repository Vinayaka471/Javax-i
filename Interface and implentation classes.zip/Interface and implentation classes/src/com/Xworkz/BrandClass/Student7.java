package com.Xworkz.BrandClass;

import com.Xworkz.Internal.Yash;
import com.Xworkz.Internal.Yuvan;

public class Student7 implements Yash, Yuvan {
    @Override
    public void schoolRulls() {
        System.out.println("School Rulls for Student.");
    }

    @Override
    public void gameRulls() {
        System.out.println("Game Rulls For Student.");

    }

    @Override
    public void examRulls() {
        System.out.println("Exam Rulls for Student.");

    }
}
