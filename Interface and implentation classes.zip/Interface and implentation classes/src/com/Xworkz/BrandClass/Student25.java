package com.Xworkz.BrandClass;

import com.Xworkz.Internal.*;

public class Student25 implements Room, PG, Hostel, HomeStay, Hotel {
    @Override
    public void iteamRulls() {
        System.out.println("Items Rules");
    }

    @Override
    public void billRulls() {
        System.out.println("Bill Rules");

    }

    @Override
    public void orderRulls() {
        System.out.println("Oredr Rules");

    }

    @Override
    public void fees() {
        System.out.println("Fees Rules");

    }

    @Override
    public void food() {
        System.out.println("Food Rules");

    }

    @Override
    public void admission() {
        System.out.println("Admission Rules");

    }

    @Override
    public void rentRull() {
        System.out.println("Rent Rules");
    }

    @Override
    public void cleanRulls() {
        System.out.println("Clean Rules");

    }

    @Override
    public void lockRulls() {
        System.out.println("Lock Rules.");

    }
}
