package com.Xworkz.BrandClass;

import com.Xworkz.Internal.Aakhil;
import com.Xworkz.Internal.Abhi;

public class Student18 implements Aakhil, Abhi {
    @Override
    public void homeRulls() {
        System.out.println("Home Rules");
    }

    @Override
    public void schoolRulls() {
        System.out.println("School Rules");
    }

    @Override
    public void gameRulls() {
        System.out.println("Game Rules");

    }

    @Override
    public void examRulls() {
        System.out.println("Exam Rule");

    }

    @Override
    public void collegeRulls() {
        System.out.println("College Rule");

    }
}
