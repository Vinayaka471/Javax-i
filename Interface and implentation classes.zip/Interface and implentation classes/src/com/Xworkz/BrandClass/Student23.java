package com.Xworkz.BrandClass;

import com.Xworkz.Internal.Yash;
import com.Xworkz.Internal.Zaiden;

public class Student23  implements Zaiden, Yash {

    @Override
    public void schoolRulls() {
        System.out.println("School Rules");
    }

    @Override
    public void gameRulls() {
        System.out.println("Game Rules");

    }

    @Override
    public void examRulls() {
        System.out.println("Exam Rules");
    }
}

