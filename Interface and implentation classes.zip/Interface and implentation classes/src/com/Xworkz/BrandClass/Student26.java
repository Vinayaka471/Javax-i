package com.Xworkz.BrandClass;

import com.Xworkz.Internal.*;

import java.util.logging.SocketHandler;

public class Student26 implements Abhi, Advik, Aakhil, Sell, Buy {
    @Override
    public void homeRulls() {
        System.out.println("Home Rules");
    }

    @Override
    public void collegeRulls() {
        System.out.println("College Rules");

    }

    @Override
    public void schoolRulls() {
        System.out.println("School Rules");

    }

    @Override
    public void gameRulls() {
        System.out.println("Game Rules");

    }

    @Override
    public void examRulls() {
        System.out.println("Exam Rules");

    }

    @Override
    public void documentRull() {
        System.out.println("Document Rules");

    }

    @Override
    public void priceRull() {
        System.out.println("Price Rules");

    }

    @Override
    public void changeRull() {
        System.out.println("Change Rules");

    }
}
