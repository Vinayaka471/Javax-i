package com.Xworkz.BrandClass;

import com.Xworkz.Internal.Arun;
import com.Xworkz.Internal.Bhrath;

public class Student9 implements Arun, Bhrath {
    @Override
    public void schoolRulls() {
        System.out.println("School Rules");
    }

    @Override
    public void gameRulls() {
        System.out.println("Game Rules");

    }

    @Override
    public void examRulls() {
        System.out.println("Exam Rules");
    }
}
