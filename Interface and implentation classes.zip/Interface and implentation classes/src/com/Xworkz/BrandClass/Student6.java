package com.Xworkz.BrandClass;

import com.Xworkz.Internal.School;
import com.Xworkz.Internal.college;

public class Student6 implements School, college {
    @Override
    public void timeRulls() {
        System.out.println("Time Rule");
    }

    @Override
    public void gameRulls() {
        System.out.println("Game Rule");

    }

    @Override
    public void subRulls() {
        System.out.println("Sub Rule");

    }

    @Override
    public void feesRulls() {
        System.out.println("Fees Rule");

    }

    @Override
    public void streemRulls() {
        System.out.println("Steem Rule");

    }

    @Override
    public void courseRulls() {
        System.out.println("Course Rule");

    }
}
