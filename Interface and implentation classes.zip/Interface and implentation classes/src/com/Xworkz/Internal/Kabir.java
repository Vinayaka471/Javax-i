package com.Xworkz.Internal;

public interface Kabir {
    void teacherRulls();
    void principalRulls();
    void presidentRulls();
}
