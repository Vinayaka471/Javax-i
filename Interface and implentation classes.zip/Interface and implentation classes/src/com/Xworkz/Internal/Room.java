package com.Xworkz.Internal;

public interface Room {
    void rentRull();
    void cleanRulls();
    void lockRulls();
}
