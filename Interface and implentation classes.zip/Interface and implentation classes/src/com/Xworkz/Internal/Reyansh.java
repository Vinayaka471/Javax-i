package com.Xworkz.Internal;

public interface Reyansh {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
