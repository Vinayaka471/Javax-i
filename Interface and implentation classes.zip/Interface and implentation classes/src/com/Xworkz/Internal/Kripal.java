package com.Xworkz.Internal;

public interface Kripal {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
