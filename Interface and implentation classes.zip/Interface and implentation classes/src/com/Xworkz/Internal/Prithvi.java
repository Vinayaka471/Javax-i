package com.Xworkz.Internal;

public interface Prithvi {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
