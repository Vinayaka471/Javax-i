package com.Xworkz.Internal;

public interface Manan {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
