package com.Xworkz.Internal;

public interface Aakhil {

    void homeRulls();
    void schoolRulls();
    void collegeRulls();

}
