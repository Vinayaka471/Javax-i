package com.Xworkz.Internal;

public interface Zaiden {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
