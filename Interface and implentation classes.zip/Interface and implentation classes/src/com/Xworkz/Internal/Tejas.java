package com.Xworkz.Internal;

public interface Tejas {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
