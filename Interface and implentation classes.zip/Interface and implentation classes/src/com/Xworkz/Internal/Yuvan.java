package com.Xworkz.Internal;

public interface Yuvan {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
