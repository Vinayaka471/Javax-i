package com.Xworkz.Internal;

public interface Hostel {
    void fees();
    void food();
    void admission();
}
