package com.Xworkz.Internal;

public interface car {
    void drivingRulls();
    void speedRulls();
    void rulls();
}
