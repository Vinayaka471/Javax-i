package com.Xworkz.Internal;

public interface HomeStay {
    void iteamRulls();
    void billRulls();
    void orderRulls();
}
