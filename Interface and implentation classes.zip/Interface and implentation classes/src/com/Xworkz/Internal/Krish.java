package com.Xworkz.Internal;

public interface Krish {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
