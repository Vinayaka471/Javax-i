package com.Xworkz.Internal;

public interface Vikram {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
