package com.Xworkz.Internal;

public interface Advik {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
