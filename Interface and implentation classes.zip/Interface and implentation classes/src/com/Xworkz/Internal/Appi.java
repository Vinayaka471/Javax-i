package com.Xworkz.Internal;

public interface Appi {
    void teacherRulls();
    void principalRulls();
    void presidentRulls();
}
