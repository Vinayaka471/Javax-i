package com.Xworkz.Internal;

public interface Darshan {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
