package com.Xworkz.Internal;

public interface Kian {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
