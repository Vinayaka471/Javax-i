package com.Xworkz.Internal;

public interface college {
    void feesRulls();
    void streemRulls();
    void courseRulls();
}
