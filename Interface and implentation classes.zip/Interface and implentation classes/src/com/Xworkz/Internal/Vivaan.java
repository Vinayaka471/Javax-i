package com.Xworkz.Internal;

public interface Vivaan {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
