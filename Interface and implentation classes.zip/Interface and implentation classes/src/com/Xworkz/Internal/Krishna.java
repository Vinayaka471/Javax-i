package com.Xworkz.Internal;

public interface Krishna {

    void schoolRulls();
    void gameRulls();
    void examRulls();
}
