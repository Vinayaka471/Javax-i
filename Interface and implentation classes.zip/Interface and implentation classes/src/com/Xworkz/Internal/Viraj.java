package com.Xworkz.Internal;

public interface Viraj {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
