package com.Xworkz.Internal;

public interface PG {
    void fees();
    void food();
    void admission();
}
