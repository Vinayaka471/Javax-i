package com.Xworkz.Internal;

public interface Nishant {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
