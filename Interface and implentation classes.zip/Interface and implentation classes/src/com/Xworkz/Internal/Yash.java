package com.Xworkz.Internal;

public interface Yash {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
