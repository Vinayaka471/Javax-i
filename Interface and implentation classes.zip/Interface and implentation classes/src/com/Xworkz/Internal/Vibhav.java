package com.Xworkz.Internal;

public interface Vibhav {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
