package com.Xworkz.Internal;

public interface HighWay {
    void speedRulls();
    void drivingRulls();
    void symbolRulls();
}
