package com.Xworkz.Internal;

public interface Sell {
    void documentRull();
    void priceRull();
    void changeRull();
}
