package com.Xworkz.Internal;

public interface Tanmay {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
