package com.Xworkz.Internal;

public interface Abhi {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
