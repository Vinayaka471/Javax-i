package com.Xworkz.Internal;

public interface Gautam {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
