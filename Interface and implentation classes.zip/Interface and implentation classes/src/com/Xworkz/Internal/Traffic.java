package com.Xworkz.Internal;

public interface Traffic {
    void parkingRulls();
    void signalRulls();
    void drivingRulls();
}
