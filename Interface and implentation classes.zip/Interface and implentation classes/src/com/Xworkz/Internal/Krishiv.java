package com.Xworkz.Internal;

public interface Krishiv {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
