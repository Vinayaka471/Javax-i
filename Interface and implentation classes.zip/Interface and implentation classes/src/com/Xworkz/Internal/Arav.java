package com.Xworkz.Internal;

public interface Arav {
    void teacherRulls();
    void principalRulls();
    void presidentRulls();
}
