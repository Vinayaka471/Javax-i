package com.Xworkz.Internal;

public interface Shaurya {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
