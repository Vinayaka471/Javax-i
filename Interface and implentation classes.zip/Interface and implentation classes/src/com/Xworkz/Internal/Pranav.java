package com.Xworkz.Internal;

public interface Pranav {
    void schoolRulls();

    void gameRulls();

    void examRulls();
}
