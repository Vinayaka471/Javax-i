package com.Xworkz.Internal;

public interface Harvith {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
