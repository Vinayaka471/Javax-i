package com.Xworkz.Internal;

public interface Lodge {
    void amountRulls();
    void stayRulls();
    void admissionRulls();
}
