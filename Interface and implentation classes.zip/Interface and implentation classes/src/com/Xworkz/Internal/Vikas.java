package com.Xworkz.Internal;

public interface Vikas {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
