package com.Xworkz.Internal;

public interface Karthik {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
