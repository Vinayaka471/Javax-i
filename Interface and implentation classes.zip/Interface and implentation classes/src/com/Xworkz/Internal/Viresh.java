package com.Xworkz.Internal;

public interface Viresh {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
