package com.Xworkz.Internal;

public interface Bhrath {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
