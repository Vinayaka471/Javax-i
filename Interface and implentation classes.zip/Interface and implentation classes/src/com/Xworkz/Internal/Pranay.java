package com.Xworkz.Internal;

public interface Pranay {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
