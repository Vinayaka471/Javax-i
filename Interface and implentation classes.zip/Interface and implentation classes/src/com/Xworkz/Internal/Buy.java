package com.Xworkz.Internal;

public interface Buy {
    void documentRull();
    void priceRull();
    void changeRull();
}
