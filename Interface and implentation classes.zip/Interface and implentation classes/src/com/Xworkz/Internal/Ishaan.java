package com.Xworkz.Internal;

public interface Ishaan {
    void schoolRulls();
    void gameRulls();
    void examRulls();
}
