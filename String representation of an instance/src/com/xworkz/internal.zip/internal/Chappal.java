package com.xworkz.internal;

public class Chappal {
    public Chappal(){
        System.out.println("No Argument Chappal Constructor");
    }
}
