package com.xworkz.internal;

public class School {
    public School(){
        System.out.println("No Argument School Constructor");
    }
}
