package com.xworkz.internal;

public class App {
    public App(){
        System.out.println("No argument App Constructor");
    }
}
