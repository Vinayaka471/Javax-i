package com.xworkz.internal;

public class Animal {
    public Animal(){
        System.out.println("No Argument Animal Constructor");
    }
}
