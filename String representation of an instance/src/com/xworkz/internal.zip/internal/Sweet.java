package com.xworkz.internal;

public class Sweet {
    public void Sweet(){
        System.out.println("No Argument Sweet Constructor");
    }
}
