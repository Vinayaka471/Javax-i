package com.xworkz.internal;

public class Appu {
    public Appu()
    {
        System.out.println("No args Appu Constructor");
    }
}
