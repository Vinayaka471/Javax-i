package com.xworkz.internal;

public class Bulb {
    public Bulb(){
        System.out.println("No args Bulb Constructor");
    }
}
