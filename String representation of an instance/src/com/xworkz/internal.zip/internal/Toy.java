package com.xworkz.internal;

public class Toy {
    public Toy(){
        System.out.println("No Argument Toy Constructor");
    }
}
