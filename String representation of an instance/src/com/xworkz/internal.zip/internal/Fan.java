package com.xworkz.internal;

public class Fan {
    public Fan(){
        System.out.println("No argument Fan  costructor");
    }
}
