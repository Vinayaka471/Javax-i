package com.xworkz.internal;

public class Police {
    public Police(){
        System.out.println("No Argument Poilic COnstructor");
    }
}
