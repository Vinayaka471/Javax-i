package com.xworkz.internal;

public class Shampoo {
    public Shampoo(){
        System.out.println("No Argument Shampoo Constructor");
    }
}
