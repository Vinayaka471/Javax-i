package com.xworkz.internal;

public class Gadgets {
    public Gadgets(){
        System.out.println("No argument Gadget Constructor");

    }
}
