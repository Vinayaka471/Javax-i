package com.xworkz.internal;

public class Soap {
    public Soap(){
        System.out.println("No Arguments Soap Constructor");
    }
}
