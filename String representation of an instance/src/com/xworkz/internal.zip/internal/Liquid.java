package com.xworkz.internal;

public class Liquid {
    public Liquid(){
        System.out.println("No Argument Liquid Constructor");
    }
}
