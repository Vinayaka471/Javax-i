package com.xworkz.internal;

public class Metal {
    public Metal(){
        System.out.println("No argument Metal Constructor");
    }
}
