package com.xworkz.internal;

public class Bag {
    public Bag(){
        System.out.println("No Argument Bag Constructor");
    }
}
