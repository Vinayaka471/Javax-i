package com.xworkz.internal;

public class Vehicle {
    public Vehicle(){
        System.out.println("No arguments Vehicle Constructor");
    }
}
