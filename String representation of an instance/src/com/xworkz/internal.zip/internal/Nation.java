package com.xworkz.internal;

public class Nation {
    public Nation(){
        System.out.println("No arguments Constructor Nation");
    }
}
