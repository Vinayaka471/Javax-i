package com.xworkz.internal;

public class Cloth {
    public Cloth(){
        System.out.println("No Argument Cloth Constructor");
    }
}
