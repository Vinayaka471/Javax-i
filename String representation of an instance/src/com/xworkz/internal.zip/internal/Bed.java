package com.xworkz.internal;

public class Bed {
    public Bed(){
        System.out.println("No argument Bed Constructor");
    }
}
