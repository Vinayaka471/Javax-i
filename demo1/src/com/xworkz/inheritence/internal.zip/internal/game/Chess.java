package com.xworkz.inheritence.internal.game;

public class Chess extends Game {
    public Chess() {
        super();
        System.out.println("Running non-arg constructor Chess");
    }
}
