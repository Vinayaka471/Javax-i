package com.xworkz.inheritence.internal.mountain;

public class Mountain {
    public Mountain() {
        System.out.println("Running non-arg constructor Mountain");
    }
    public void height() {
        System.out.println("Mountain has a height");
    }
    public void climate() {
        System.out.println("Mountain has a unique climate");
    }
    public void location() {
        System.out.println("Mountain is located in different regions");
    }
    public void trekking() {
        System.out.println("Mountain is used for trekking");
    }
    public void wildlife() {
        System.out.println("Mountain supports unique wildlife");
    }
}
