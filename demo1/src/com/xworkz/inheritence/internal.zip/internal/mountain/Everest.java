package com.xworkz.inheritence.internal.mountain;

public class Everest extends Mountain {
    public Everest() {
        super();
        System.out.println("Running non-arg constructor Everest");
    }
}
