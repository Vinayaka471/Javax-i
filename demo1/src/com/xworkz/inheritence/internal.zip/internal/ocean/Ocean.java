package com.xworkz.inheritence.internal.ocean;

public class Ocean {
    public Ocean() {
        System.out.println("Running non-arg constructor Ocean");
    }
    public void depth() {
        System.out.println("Ocean has great depth");
    }
    public void marineLife() {
        System.out.println("Ocean supports diverse marine life");
    }
    public void waves() {
        System.out.println("Ocean has strong waves");
    }
    public void temperature() {
        System.out.println("Ocean water temperature varies");
    }
    public void tides() {
        System.out.println("Ocean experiences tides");
    }
}
