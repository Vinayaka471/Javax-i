package com.xworkz.inheritence.internal.ocean;

public class Pacific extends Ocean {
    public Pacific() {
        super();
        System.out.println("Running non-arg constructor Pacific");
    }
}
