package com.xworkz.inheritence.internal.country;

public class India extends Country {
    public India() {
        super();
        System.out.println("Running non-arg constructor India");
    }
}
