package com.xworkz.inheritence.internal.country;

public class Country {
    public Country() {
        System.out.println("Running non-arg constructor Country");
    }
    public void name() {
        System.out.println("Country has a name");
    }
    public void population() {
        System.out.println("Country has a population");
    }
    public void culture() {
        System.out.println("Country has a culture");
    }
    public void economy() {
        System.out.println("Country has an economy");
    }
    public void government() {
        System.out.println("Country has a government");
    }
}
