package com.xworkz.inheritence.internal.sports;

public class Football extends Sports {
    public Football() {
        super();
        System.out.println("Running non-arg constructor Football");
    }
}
