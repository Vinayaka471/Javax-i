package com.xworkz.inheritence.internal.sports;

public class Sports {
    public Sports() {
        System.out.println("Running non-arg constructor Sports");
    }
    public void play() {
        System.out.println("Sports is played");
    }
    public void rules() {
        System.out.println("Sports have rules");
    }
    public void competition() {
        System.out.println("Sports involve competition");
    }
    public void team() {
        System.out.println("Sports can have teams");
    }
    public void training() {
        System.out.println("Sports require training");
    }
}
