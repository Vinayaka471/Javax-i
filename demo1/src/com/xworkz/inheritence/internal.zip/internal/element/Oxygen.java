package com.xworkz.inheritence.internal.element;

public class Oxygen extends Element {
    public Oxygen() {
        super();
        System.out.println("Running non-arg constructor Oxygen");
    }
}
