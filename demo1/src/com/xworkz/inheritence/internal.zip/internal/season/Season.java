package com.xworkz.inheritence.internal.season;

public class Season {
    public Season() {
        System.out.println("Running non-arg constructor Season");
    }
    public void weather() {
        System.out.println("Season affects the weather");
    }
    public void duration() {
        System.out.println("Season lasts for a few months");
    }
    public void activities() {
        System.out.println("Different seasons allow different activities");
    }
    public void temperature() {
        System.out.println("Seasons have different temperatures");
    }
    public void impact() {
        System.out.println("Seasons impact nature and humans");
    }
}
