package com.xworkz.inheritence.internal.season;

public class Winter extends Season {
    public Winter() {
        super();
        System.out.println("Running non-arg constructor Winter");
    }
}
