package com.xworkz.inheritence.internal.phone;

public class Smartphone extends Phone {
    public Smartphone() {
        super();
        System.out.println("Running non-arg constructor Smartphone");
    }
}
