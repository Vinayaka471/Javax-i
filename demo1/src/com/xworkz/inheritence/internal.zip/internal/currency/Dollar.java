package com.xworkz.inheritence.internal.currency;

public class Dollar extends Currency {
    public Dollar() {
        super();
        System.out.println("Running non-arg constructor Dollar");
    }
}
