package com.xworkz.inheritence.internal.language;

public class Java extends Language {
    public Java() {
        super();
        System.out.println("Running non-arg constructor Java");
    }
}
