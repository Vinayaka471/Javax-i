package com.xworkz.inheritence.internal.charger;

public class Wire extends Charger{
    public Wire(){
        System.out.println("running non-arg const Wire");
    }
}
