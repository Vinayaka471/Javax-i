package com.xworkz.inheritence.internal.charger;

public class Charger {
    public Charger(){
        System.out.println("running non-arg const Charger");
    }
    public void plug(){
        System.out.println("plug Charger");
    }
    public void white(){
        System.out.println("white Charger");
    }
    public void small(){
        System.out.println("small Charger");
    }
    public void cPin(){
        System.out.println("cPin Charger");
    }
    public void phone(){
        System.out.println("phone Charger");
    }
}
