package com.xworkz.inheritence.internal.animal;

public class Dog extends Animal {
    public Dog() {
        super();
        System.out.println("Running non-arg constructor Dog");
    }
}
