package com.xworkz.inheritence.internal.bird;

public class Eagle extends Bird {
    public Eagle() {
        super();
        System.out.println("Running non-arg constructor Eagle");
    }
}
