package com.xworkz.inheritence.internal.bird;

public class Bird {
    public Bird() {
        System.out.println("Running non-arg constructor Bird");
    }
    public void fly() {
        System.out.println("Bird can fly");
    }
    public void feathers() {
        System.out.println("Bird has feathers");
    }
    public void laysEggs() {
        System.out.println("Bird lays eggs");
    }
    public void sound() {
        System.out.println("Bird makes sounds");
    }
    public void vision() {
        System.out.println("Bird has sharp vision");
    }
}
