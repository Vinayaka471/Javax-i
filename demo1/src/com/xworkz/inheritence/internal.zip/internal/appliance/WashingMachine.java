package com.xworkz.inheritence.internal.appliance;

public class WashingMachine extends Appliance {
    public WashingMachine() {
        super();
        System.out.println("Running non-arg constructor WashingMachine");
    }
}
