package com.xworkz.inheritence.internal.clothing;

public class TShirt extends Clothing {
    public TShirt() {
        super();
        System.out.println("Running non-arg constructor TShirt");
    }
}
