package com.xworkz.inheritence.internal.clothing;

public class Clothing {
    public Clothing() {
        System.out.println("Running non-arg constructor Clothing");
    }
    public void wear() {
        System.out.println("Clothing is worn");
    }
    public void material() {
        System.out.println("Clothing is made of different materials");
    }
    public void size() {
        System.out.println("Clothing has different sizes");
    }
    public void brand() {
        System.out.println("Clothing has brands");
    }
    public void design() {
        System.out.println("Clothing has designs");
    }
}
