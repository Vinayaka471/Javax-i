package com.xworkz.inheritence.internal.tree;

public class Oak extends Tree {
    public Oak() {
        super();
        System.out.println("Running non-arg constructor Oak");
    }
}
