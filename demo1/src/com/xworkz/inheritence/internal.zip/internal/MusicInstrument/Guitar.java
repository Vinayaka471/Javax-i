package com.xworkz.inheritence.internal.MusicInstrument;

public class Guitar extends MusicInstrument {
        public Guitar() {
            super();
            System.out.println("Running non-arg constructor Guitar");
        }
}
