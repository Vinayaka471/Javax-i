package com.xworkz.inheritence.internal.drink;

public class Juice extends Drink {
    public Juice() {
        super();
        System.out.println("Running non-arg constructor Juice");
    }
}
