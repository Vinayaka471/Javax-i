package com.xworkz.inheritence.internal.river;

public class Nile extends River {
    public Nile() {
        super();
        System.out.println("Running non-arg constructor Nile");
    }
}
