package com.xworkz.inheritence.internal.planet;

public class Earth extends Planet {
    public Earth() {
        super();
        System.out.println("Running non-arg constructor Earth");
    }
}
