package com.xworkz.inheritence.internal.bottle;

public class Bottle {
    public Bottle(){
        System.out.println("running non-arg const Bottle");
    }
    public void fill(){
        System.out.println("fill bottle");
    }
    public void water(){
        System.out.println("water bottle");
    }
    public void milk(){
        System.out.println("milk bottle");
    }
    public void glass(){
        System.out.println("glass bottle");
    }
    public void frozen(){
        System.out.println("frozen bottle");
    }
}
