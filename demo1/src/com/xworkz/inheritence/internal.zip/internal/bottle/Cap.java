package com.xworkz.inheritence.internal.bottle;

public class Cap extends Bottle{
    public Cap(){
        super();
        System.out.println("running non-arg const cap");
    }
}
