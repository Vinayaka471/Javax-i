package com.xworkz.inheritence.internal.city;

public class City {
    public City() {
        System.out.println("Running non-arg constructor City");
    }
    public void population() {
        System.out.println("City has a population");
    }
    public void infrastructure() {
        System.out.println("City has infrastructure");
    }
    public void tourism() {
        System.out.println("City attracts tourists");
    }
    public void culture() {
        System.out.println("City has a diverse culture");
    }
    public void economy() {
        System.out.println("City has an economy");
    }
}
