package com.xworkz.inheritence.internal.city;

public class NewYork extends City {
    public NewYork() {
        super();
        System.out.println("Running non-arg constructor NewYork");
    }
}
