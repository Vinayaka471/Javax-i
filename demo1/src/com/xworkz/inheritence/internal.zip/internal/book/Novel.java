package com.xworkz.inheritence.internal.book;

public class Novel extends Book {
    public Novel() {
        super();
        System.out.println("Running non-arg constructor Novel");
    }
}
