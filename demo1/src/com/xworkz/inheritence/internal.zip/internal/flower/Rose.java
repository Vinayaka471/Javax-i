package com.xworkz.inheritence.internal.flower;

public class Rose extends Flower {
    public Rose() {
        super();
        System.out.println("Running non-arg constructor Rose");
    }
}
