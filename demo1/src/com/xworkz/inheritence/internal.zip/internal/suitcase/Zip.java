package com.xworkz.inheritence.internal.suitcase;

public class Zip extends Suitcase{
    public Zip(){
        System.out.println("running non-arg const Zip");
    }
}
