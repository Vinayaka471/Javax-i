package com.xworkz.inheritence.internal.transportation;

public class Transportation {
    public Transportation() {
        System.out.println("Running non-arg constructor Transportation");
    }
    public void move() {
        System.out.println("Transportation is used for moving");
    }
    public void speed() {
        System.out.println("Transportation has different speeds");
    }
    public void fuel() {
        System.out.println("Transportation requires fuel");
    }
    public void capacity() {
        System.out.println("Transportation has capacity");
    }
    public void type() {
        System.out.println("Transportation has different types");
    }
}
