package com.xworkz.inheritence.internal.transportation;

public class Train extends Transportation {
    public Train() {
        super();
        System.out.println("Running non-arg constructor Train");
    }
}
