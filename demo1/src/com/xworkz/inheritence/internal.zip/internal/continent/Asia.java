package com.xworkz.inheritence.internal.continent;

public class Asia extends Continent {
    public Asia() {
        super();
        System.out.println("Running non-arg constructor Asia");
    }
}
