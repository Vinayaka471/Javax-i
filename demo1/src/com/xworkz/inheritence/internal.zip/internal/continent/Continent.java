package com.xworkz.inheritence.internal.continent;

public class Continent {
    public Continent() {
        System.out.println("Running non-arg constructor Continent");
    }
    public void countries() {
        System.out.println("Continent has multiple countries");
    }
    public void population() {
        System.out.println("Continent has a large population");
    }
    public void culture() {
        System.out.println("Continent has diverse cultures");
    }
    public void economy() {
        System.out.println("Continent contributes to the global economy");
    }
    public void climate() {
        System.out.println("Continent has different climates");
    }
}
