package com.xworkz.inheritence.internal.lock;

public class Key {
    public Key(){
        System.out.println("running non-arg const Key");
    }
    public void open(){
        System.out.println("open Key");
    }
    public void white(){
        System.out.println("white Key");
    }
    public void small(){
        System.out.println("small Key");
    }
    public void close(){
        System.out.println("close Key");
    }
    public void big(){
        System.out.println("big Key");
    }
}
