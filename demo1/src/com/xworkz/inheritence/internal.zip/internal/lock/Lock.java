package com.xworkz.inheritence.internal.lock;

public class Lock extends Key{
    public Lock(){
        System.out.println("running non-arg const Lock");
    }
}
