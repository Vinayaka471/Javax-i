package com.xworkz.inheritence.internal.gadget;

public class Tablet extends Gadget {
    public Tablet() {
        super();
        System.out.println("Running non-arg constructor Tablet");
    }
}
