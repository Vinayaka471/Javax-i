package com.xworkz.inheritence.internal.employee;

public class Manager extends Employee {
    public Manager() {
        super();
        System.out.println("Running non-arg constructor Manager");
    }
}
