package com.xworkz.inheritence.internal.employee;

public class Employee {
    public Employee() {
        System.out.println("Running non-arg constructor Employee");
    }
    public void work() {
        System.out.println("Employee is working");
    }
    public void salary() {
        System.out.println("Employee gets salary");
    }
    public void benefits() {
        System.out.println("Employee gets benefits");
    }
    public void experience() {
        System.out.println("Employee gains experience");
    }
    public void department() {
        System.out.println("Employee belongs to a department");
    }
}
