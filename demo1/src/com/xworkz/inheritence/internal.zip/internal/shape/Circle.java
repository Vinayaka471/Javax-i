package com.xworkz.inheritence.internal.shape;

public class Circle extends Shape {
    public Circle() {
        super();
        System.out.println("Running non-arg constructor Circle");
    }
}
