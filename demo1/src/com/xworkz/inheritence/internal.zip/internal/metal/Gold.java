package com.xworkz.inheritence.internal.metal;

public class Gold extends Metal {
    public Gold() {
        super();
        System.out.println("Running non-arg constructor Gold");
    }
}
