package com.xworkz.inheritence.internal.metal;

public class Metal {
    public Metal() {
        System.out.println("Running non-arg constructor Metal");
    }
    public void conductivity() {
        System.out.println("Metal is a good conductor of electricity");
    }
    public void durability() {
        System.out.println("Metal is durable");
    }
    public void malleability() {
        System.out.println("Metal can be shaped into different forms");
    }
    public void density() {
        System.out.println("Metal has a certain density");
    }
    public void corrosion() {
        System.out.println("Some metals corrode over time");
    }
}
