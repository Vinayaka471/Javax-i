package com.xworkz.inheritence.internal.food;

public class Burger extends Food {
    public Burger() {
        super();
        System.out.println("Running non-arg constructor Burger");
    }
}
