package com.xworkz.inheritence.internal.plant;

public class Flower extends Plant {
    public Flower() {
        super();
        System.out.println("Running non-arg constructor Flower");
    }
}
