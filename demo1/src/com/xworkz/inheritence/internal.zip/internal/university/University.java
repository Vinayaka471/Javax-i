package com.xworkz.inheritence.internal.university;

public class University {
    public University() {
        System.out.println("Running non-arg constructor University");
    }
    public void education() {
        System.out.println("University provides education");
    }
    public void research() {
        System.out.println("University conducts research");
    }
    public void students() {
        System.out.println("University has students");
    }
    public void faculty() {
        System.out.println("University has faculty members");
    }
    public void campus() {
        System.out.println("University has a campus");
    }
}
