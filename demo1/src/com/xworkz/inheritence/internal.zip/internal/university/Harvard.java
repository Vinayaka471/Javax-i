package com.xworkz.inheritence.internal.university;

public class Harvard extends University {
    public Harvard() {
        super();
        System.out.println("Running non-arg constructor Harvard");
    }
}
