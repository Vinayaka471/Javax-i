package com.xworkz.inheritence.internal.vehicle;

public class Car extends Vehicle {
    public Car() {
        super();
        System.out.println("Running non-arg constructor Car");
    }
}
