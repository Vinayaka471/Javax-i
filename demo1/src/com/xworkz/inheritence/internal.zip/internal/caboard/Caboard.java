package com.xworkz.inheritence.internal.caboard;

public class Caboard {
    public Caboard(){
        System.out.println("running non-arg const Caboard");
    }
    public void lock(){
        System.out.println("lock Caboard");
    }
    public void key(){
        System.out.println("key Caboard");
    }
    public void handle(){
        System.out.println("handle Caboard");
    }
    public void open(){
        System.out.println("open Caboard");
    }
    public void close(){
        System.out.println("close Caboard");
    }
}
