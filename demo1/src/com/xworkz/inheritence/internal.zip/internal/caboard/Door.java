package com.xworkz.inheritence.internal.caboard;

public class Door extends Caboard{
    public Door(){
        System.out.println("running non-arg const Door");
    }
}
