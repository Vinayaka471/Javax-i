package com.xworkz.inheritence.internal.bank;

public class HDFCBank extends Bank {
    public HDFCBank() {
        super();
        System.out.println("Running non-arg constructor HDFC Bank");
    }
}
