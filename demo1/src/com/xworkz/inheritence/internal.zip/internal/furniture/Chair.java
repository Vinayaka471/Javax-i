package com.xworkz.inheritence.internal.furniture;

public class Chair extends Furniture {
    public Chair() {
        super();
        System.out.println("Running non-arg constructor Chair");
    }
}
