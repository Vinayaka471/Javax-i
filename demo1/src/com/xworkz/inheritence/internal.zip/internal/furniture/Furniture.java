package com.xworkz.inheritence.internal.furniture;

public class Furniture {
    public Furniture() {
        System.out.println("Running non-arg constructor Furniture");
    }
    public void support() {
        System.out.println("Furniture provides support");
    }
    public void material() {
        System.out.println("Furniture is made of different materials");
    }
    public void weight() {
        System.out.println("Furniture has different weights");
    }
    public void move() {
        System.out.println("Furniture can be moved");
    }
    public void design() {
        System.out.println("Furniture has different designs");
    }
}
